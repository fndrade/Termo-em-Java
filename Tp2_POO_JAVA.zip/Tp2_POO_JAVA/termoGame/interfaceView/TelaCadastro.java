import javax.swing.*; //biblioteca da interface
import java.awt.*; //biblioteca de layout, cores e fontes
import java.awt.event.ActionEvent; //classe de ação
import java.awt.event.ActionListener; //interface q responde ação dos botoes

//OBS: Poucos comentarios pq utilizamos a mesma base de funções do Tela de Login

//herança de jframe
public class TelaCadastro extends JFrame {
    // campo de entrada pra usuario e senha e confirmação de senha
    private JTextField campoUsuario;
    private JPasswordField campoSenha;
    private JPasswordField campoConfirmaSenha;

    // construtor para tela de cadastro
    public TelaCadastro(final AuthController authController, final JFrame telaAnterior) {

        // configurações da janela, segue mesmo padrão de login, com titulo, tamanho...
        setTitle("TERMO - Cadastro");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // fecha somente a janela de cadastro depois de concluido
        setLocationRelativeTo(null); // centraliza
        setResizable(false); // impede redimensionamento

        // Painel principal
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // margem
        painel.setBackground(new Color(245, 245, 250)); // fundo

        // Título
        JLabel titulo = new JLabel("Cadastro de Usuário", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 22)); // negrito tam 22
        titulo.setForeground(new Color(50, 50, 120)); // azul
        painel.add(titulo, BorderLayout.NORTH); // posiciona titulo no topo

        // Formulário
        JPanel painelForm = new JPanel(new GridLayout(6, 1, 10, 10)); // campo de entrada com 6 linhas e 1 coluna
        painelForm.setBackground(new Color(245, 245, 250));

        JLabel lblUsuario = new JLabel("Nome de Usuário:"); // nome de usuario
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // fonte e tamanho
        campoUsuario = new JTextField();
        campoUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campoUsuario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 200), 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)));

        // senha
        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campoSenha = new JPasswordField();
        campoSenha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campoSenha.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 200), 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)));

        // confirmação de senha
        JLabel lblConfirmaSenha = new JLabel("Confirmar Senha:");
        lblConfirmaSenha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campoConfirmaSenha = new JPasswordField();
        campoConfirmaSenha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campoConfirmaSenha.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 200), 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)));

        // adicionamos todos os componentes na tela
        painelForm.add(lblUsuario);
        painelForm.add(campoUsuario);
        painelForm.add(lblSenha);
        painelForm.add(campoSenha);
        painelForm.add(lblConfirmaSenha);
        painelForm.add(campoConfirmaSenha);

        painel.add(painelForm, BorderLayout.CENTER); // posiciona no centro

        // Botões
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        painelBotoes.setBackground(new Color(245, 245, 250));

        JButton botaoCadastrar = new JButton("Cadastrar");
        JButton botaoVoltar = new JButton("Voltar");

        estilizarBotao(botaoCadastrar, new Color(34, 139, 34)); // verde
        estilizarBotao(botaoVoltar, new Color(128, 128, 128)); // cinza

        painelBotoes.add(botaoCadastrar);
        painelBotoes.add(botaoVoltar);
        painel.add(painelBotoes, BorderLayout.SOUTH);

        add(painel);

        // Ações
        botaoCadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String senha = new String(campoSenha.getPassword());
                String confirmaSenha = new String(campoConfirmaSenha.getPassword());

                if (!senha.equals(confirmaSenha)) {
                    JOptionPane.showMessageDialog(TelaCadastro.this, "As senhas não coincidem.", "Erro de Cadastro",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (authController.handleCadastro(usuario, senha)) {
                    JOptionPane.showMessageDialog(TelaCadastro.this, "Cadastro realizado com sucesso!");
                    dispose();
                    telaAnterior.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(TelaCadastro.this, "Nome de usuário já existe.", "Erro de Cadastro",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        botaoVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                telaAnterior.setVisible(true);
            }
        });

        setVisible(true);
    }

    // Método para estilizar botões
    private void estilizarBotao(JButton botao, Color corFundo) {
        botao.setFocusPainted(false);
        botao.setBackground(corFundo);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Segoe UI", Font.BOLD, 14));
        botao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 0, 0, 40), 1),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}
