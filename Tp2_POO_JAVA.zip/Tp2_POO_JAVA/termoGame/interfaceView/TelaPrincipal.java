import javax.swing.*; //interface
import java.awt.*; //layout
import java.awt.event.ActionEvent; //lidar com cliques
import java.awt.event.ActionListener; //interface de ações
import java.util.ArrayList; //criar lista dinamica
import java.util.List; //interface da lista
import java.text.Normalizer; //normalizar texto

//classe principal, onde o jogo vai ser exibido
public class TelaPrincipal extends JFrame {

    private Jogo jogo;
    private GameController gameController;

    private JLabel labelEstatisticas; // mostra estatisticas e tentativas
    private JLabel labelTentativasRestantes;
    private JPanel painelTentativas; // mostra onde sera exibido
    private JTextField campoEntrada; // caixa onde o jogador vai digitar a palavra
    private JButton botaoSubmeter; // botão de enter

    private List<JPanel> paineisLinhaTentativa; // lista para armazenar os paineis de cada linha de tentativa, facilita
                                                // a manipulação

    // construtor principal
    public TelaPrincipal(Jogo jogo, GameController gameController) {
        this.jogo = jogo;
        this.gameController = gameController;

        // configurações basicas da janela, titulo, tamanho, posição e redimensionamento
        setTitle("TERMO - " + jogo.getUsuarioAtual().getUsername());
        setSize(550, 750);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); // permite salvar o jogo ou fazer outras ações antes de
                                                              // sair
        setLocationRelativeTo(null);
        setResizable(false);

        // ouvinte para o fechamento de janela
        addWindowListener(new java.awt.event.WindowAdapter() {
            // quando o usuario clica no X, o metodo sairdojogo é chamado
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                gameController.sairDoJogo();
            }
        });

        // Layout principal
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(245, 245, 250));

        // Painel superior (estatísticas + ações)
        JPanel painelSuperior = new JPanel(new BorderLayout());
        painelSuperior.setBackground(new Color(245, 245, 250));
        painelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Estatísticas
        JPanel painelStats = new JPanel(new GridLayout(2, 1));
        painelStats.setBackground(new Color(245, 245, 250));

        labelEstatisticas = new JLabel("", SwingConstants.CENTER);
        labelEstatisticas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        labelTentativasRestantes = new JLabel("", SwingConstants.CENTER);
        labelTentativasRestantes.setFont(new Font("Segoe UI", Font.BOLD, 14));

        painelStats.add(labelEstatisticas);
        painelStats.add(labelTentativasRestantes);

        painelSuperior.add(painelStats, BorderLayout.CENTER);

        // Botões de ação
        JPanel painelBotoesAcao = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoesAcao.setBackground(new Color(245, 245, 250));

        JButton botaoNovaPartida = new JButton("Nova Partida");
        JButton botaoSair = new JButton("Sair");

        estilizarBotao(botaoNovaPartida, new Color(70, 130, 180)); // azul
        estilizarBotao(botaoSair, new Color(220, 20, 60)); // vermelho

        painelBotoesAcao.add(botaoNovaPartida);
        painelBotoesAcao.add(botaoSair);

        painelSuperior.add(painelBotoesAcao, BorderLayout.SOUTH);

        add(painelSuperior, BorderLayout.NORTH);

        // Grade de tentativas, cria um painel 6x5 do jogo (6 tentativas, 5 letras)
        painelTentativas = new JPanel(new GridLayout(6, 5, 5, 5));
        painelTentativas.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        paineisLinhaTentativa = new ArrayList<>(); // essa lista vai guardar cada linha
        criarGradeTentativas(); // metodo q vai construir a grade visualmente
        add(painelTentativas, BorderLayout.CENTER);

        // Painel inferior (entrada da palavra)
        JPanel painelEntrada = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        painelEntrada.setBackground(new Color(245, 245, 250));

        JLabel lblEntrada = new JLabel("Sua palavra:");
        lblEntrada.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        campoEntrada = new JTextField(10);
        campoEntrada.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        campoEntrada.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 200), 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)));

        botaoSubmeter = new JButton("Submeter");
        estilizarBotao(botaoSubmeter, new Color(34, 139, 34)); // verde

        painelEntrada.add(lblEntrada);
        painelEntrada.add(campoEntrada);
        painelEntrada.add(botaoSubmeter);

        add(painelEntrada, BorderLayout.SOUTH);

        // Ações
        botaoNovaPartida.addActionListener(e -> iniciarNovoJogo());
        botaoSair.addActionListener(e -> gameController.sairDoJogo());

        botaoSubmeter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tentativa = campoEntrada.getText().trim(); // renove os espaços extras
                if (tentativa.length() == 5) { // verifica se tem 5 letras
                    processarTentativa(tentativa);// se passa pela verificação, processa a tentativa
                    campoEntrada.setText(""); // limpa o campo de texto
                } else {
                    JOptionPane.showMessageDialog(TelaPrincipal.this, // se nao tiver 5 letras, imprime mensagem de erro
                            "Por favor, insira uma palavra de 5 letras.",
                            "Entrada Inválida", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        // se o jogador quiser iniciar novo jogo, chama a função
        iniciarNovoJogo();
        setVisible(true); // mostra a janela para o usuario
    }

    // metodos auxiliares para a construção visual do jogo
    private void criarGradeTentativas() {
        painelTentativas.removeAll(); // limpa a anterior para jogar uma nova
        paineisLinhaTentativa.clear(); // limpa a lista de linhas
        for (int i = 0; i < 6; i++) { // cria novamente 6 linhas
            JPanel linha = new JPanel(new GridLayout(1, 5, 5, 5));
            linha.setBackground(new Color(245, 245, 250));
            for (int j = 0; j < 5; j++) {
                JLabel labelLetra = new JLabel(" ", SwingConstants.CENTER);
                labelLetra.setPreferredSize(new Dimension(60, 60));
                labelLetra.setOpaque(true);
                labelLetra.setBackground(Color.LIGHT_GRAY);
                labelLetra.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                labelLetra.setFont(new Font("Segoe UI", Font.BOLD, 24));
                linha.add(labelLetra);
            }
            paineisLinhaTentativa.add(linha);
            painelTentativas.add(linha);
        }
        painelTentativas.revalidate(); // layout recalcula a posição dos componetes
        painelTentativas.repaint(); // redesenha painel
    }

    // metodo para iniciar novo jogo
    private void iniciarNovoJogo() {
        gameController.iniciarNovaPartida(); // Lógica do controlador para começar o jogo.
        atualizarInformacoesDoJogo(); // Atualiza os rótulos de estatísticas.
        campoEntrada.setEnabled(true); // Habilita o campo de entrada para o jogador.
        botaoSubmeter.setEnabled(true); // Habilita o botão de submeter.
        criarGradeTentativas(); // Cria a grade vazia.
    }

    // metodo q atualiza rotulos de estatistica e tentativas restantes
    private void atualizarInformacoesDoJogo() {
        Usuario usuario = jogo.getUsuarioAtual();
        Partida partida = jogo.getPartidaAtual();

        labelEstatisticas.setText(
                "Jogos: " + usuario.getPartidasJogadas() +
                        " | Vitórias: " + usuario.getPartidasGanhas() +
                        " | Derrotas: " + usuario.getPartidasPerdidas());

        labelTentativasRestantes.setText("Tentativas restantes: " + partida.getTentativasRestantes());
    }

    // O método mais importante pq processa a palavra que o usuário digitou.
    private void processarTentativa(String tentativa) {
        Partida partida = jogo.getPartidaAtual();
        if (partida.getTentativasRestantes() > 0) { // Verifica se ainda há tentativas.
            // Calcula o índice da linha atual na grade.
            int indiceTentativa = 6 - partida.getTentativasRestantes();
            // Pede ao controlador para processar a tentativa e nos devolver o resultado.
            EstadoLetra[] resultado = gameController.processarTentativa(tentativa);
            if (resultado != null) {
                // Normaliza a string para remover acentos, pois as caixas de letras não lidam
                // bem com eles.
                String tentativaNormalizada = Normalizer.normalize(tentativa, Normalizer.Form.NFD)
                        .replaceAll("[^\\p{ASCII}]", "");

                // Pega a linha da grade correspondente à tentativa atual.
                JPanel linha = paineisLinhaTentativa.get(indiceTentativa);
                // Percorre cada letra da tentativa.
                for (int i = 0; i < 5; i++) {
                    JLabel labelLetra = (JLabel) linha.getComponent(i); // Pega a caixinha de letra.
                    labelLetra.setText(String.valueOf(tentativaNormalizada.charAt(i))); // Coloca a letra na caixinha.
                    // Usa o 'switch' para colorir a caixinha de acordo com o resultado do
                    // controlador.
                    switch (resultado[i]) {
                        case CORRETO -> labelLetra.setBackground(new Color(0, 200, 0)); // Verde: letra correta na
                                                                                        // posição correta.
                        case POSICAO_ERRADA -> labelLetra.setBackground(new Color(255, 215, 0)); // Amarelo: letra
                                                                                                 // correta, mas na
                                                                                                 // posição errada.
                        case NAO_EXISTE -> labelLetra.setBackground(new Color(169, 169, 169)); // Cinza: letra não
                                                                                               // existe na palavra.
                    }
                }

                atualizarInformacoesDoJogo(); // Atualiza a contagem de tentativas restantes.

                // Verifica se o jogador venceu.
                if (partida.isVencedor(tentativa)) {
                    JOptionPane.showMessageDialog(this, "Parabéns! Você venceu!", "Fim de Jogo",
                            JOptionPane.INFORMATION_MESSAGE);
                    campoEntrada.setEnabled(false); // Desabilita o campo de entrada para acabar o jogo.
                    botaoSubmeter.setEnabled(false); // Desabilita o botão.
                } else if (partida.getTentativasRestantes() == 0) { // Verifica se as tentativas acabaram.
                    JOptionPane.showMessageDialog(this,
                            "Fim de jogo. A palavra secreta era: " + partida.getPalavraSecreta(),
                            "Fim de Jogo", JOptionPane.INFORMATION_MESSAGE);
                    campoEntrada.setEnabled(false); // Desabilita os campos.
                    botaoSubmeter.setEnabled(false);
                }
            }
        } else {
            // Mensagem se o jogo já tiver acabado.
            JOptionPane.showMessageDialog(this, "O jogo já terminou. Inicie uma nova partida.", "Fim de Jogo",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    // Método para estilizar botões
    // Mesmo método de estilo reutilizado em todas as classes
    private void estilizarBotao(JButton botao, Color corFundo) {
        botao.setFocusPainted(false);
        botao.setBackground(corFundo);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Segoe UI", Font.BOLD, 14));
        botao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 0, 0, 40), 1),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}
