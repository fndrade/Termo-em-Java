import javax.swing.*; //biblioteca da interface
import java.awt.*; //biblioteca de layout, cores e fontes
import java.awt.event.ActionEvent; //classe de ação
import java.awt.event.ActionListener; //interface q responde ação dos botoes

public class TelaLogin extends JFrame {

    // declaração das entradas, JTextField deixa o nome de usuario visivel
    private JTextField campoUsuario;
    private JPasswordField campoSenha; // deixa a senha escondida
    private Jogo jogo; // referencia pra abrir jogo assim q passa pelo login

    // construtor da tela de login, ele recebe o controlador de autenticação e
    // referência do jogo
    public TelaLogin(final AuthController authController, final Jogo jogo) {
        this.jogo = jogo; // guarda o jogo para uso

        setTitle("TERMO - Login"); // titulo
        setSize(500, 400); // tamanho da tela
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // fecha o programa ao sair pelo X na janela
        setLocationRelativeTo(null); // centraliza a tela
        setResizable(false); // impede redimensionamento

        // Painel principal
        JPanel painel = new JPanel(new BorderLayout()); // organiza
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // margem interna
        painel.setBackground(new Color(245, 245, 250)); // cor de fundo

        // Título
        JLabel titulo = new JLabel("Bem-vindo ao TERMO", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 22)); // coloco a font em negrito
        titulo.setForeground(new Color(50, 50, 120)); // azul
        painel.add(titulo, BorderLayout.NORTH); // ai aq coloca no topo da tela

        // formulario de usuario e senha
        JPanel painelForm = new JPanel(new GridLayout(4, 1, 10, 10)); // 4 linhas e 1 coluna de espaçamento
        painelForm.setBackground(new Color(245, 245, 250));

        JLabel lblUsuario = new JLabel("Nome de Usuário:"); // campo do usuario
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // definição de fonte e tamanho
        campoUsuario = new JTextField();
        campoUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campoUsuario.setBorder(BorderFactory.createCompoundBorder( // adiciona borda e preenchimento interno pra ficar
                                                                   // mais bonito
                BorderFactory.createLineBorder(new Color(180, 180, 200), 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)));

        // a senha vai seguir o msm padrão de usuario, a diferença é que ela fica
        // marcada por ***
        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campoSenha = new JPasswordField();
        campoSenha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        campoSenha.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 200), 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)));

        // adicionamos no painel na ordem q queremos q ele apareça
        painelForm.add(lblUsuario);
        painelForm.add(campoUsuario);
        painelForm.add(lblSenha);
        painelForm.add(campoSenha);

        // centraliza as informações no meio da tela
        painel.add(painelForm, BorderLayout.CENTER);

        // Botões centralizados tb
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        painelBotoes.setBackground(new Color(245, 245, 250));

        JButton botaoEntrar = new JButton("Entrar"); // botão de entrar e cadastrar
        JButton botaoCadastro = new JButton("Cadastrar");

        // Estilo dos botões
        estilizarBotao(botaoEntrar, new Color(70, 130, 180));
        estilizarBotao(botaoCadastro, new Color(34, 139, 34));

        painelBotoes.add(botaoEntrar);
        painelBotoes.add(botaoCadastro);
        painel.add(painelBotoes, BorderLayout.SOUTH);

        add(painel);

        // Ações (actionlistener vai fazer o botao funcionar qnd clicamos nele)
        botaoEntrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String senha = new String(campoSenha.getPassword());
                // hendlelogin é o que usamos para autenticar usuario e senha
                Usuario user = authController.handleLogin(usuario, senha);
                if (user != null) {
                    JOptionPane.showMessageDialog(TelaLogin.this, "Login bem-sucedido!");
                    abrirTelaPrincipalDoJogo(); // foi autenticado ai abre a proxima tela normalmente
                } else {
                    JOptionPane.showMessageDialog(TelaLogin.this, "Usuário ou senha inválidos.", "Erro de Login",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        /*
         * mesma logica para o botao de cadastro, a diferença é que abre
         * outra tela para preencher os cadastros, qnd finalizado, vc volta
         * a tela principal e se conecta com o login com o cadastro já feito
         */
        botaoCadastro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TelaCadastro(authController, TelaLogin.this);
                setVisible(false);
            }
        });

        setVisible(true);
    }

    // Método criado para estilizar os botoes, aq vai ser onde os botoes vao receber
    // cor, tamanho etc..
    private void estilizarBotao(JButton botao, Color corFundo) {
        botao.setFocusPainted(false); // remove contorno
        botao.setBackground(corFundo); // define cor
        botao.setForeground(Color.WHITE); // cor para branco
        botao.setFont(new Font("Segoe UI", Font.BOLD, 14)); // negrito tamanho 14
        botao.setBorder(BorderFactory.createCompoundBorder( // preenche os botoes
                BorderFactory.createLineBorder(new Color(0, 0, 0, 40), 1),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR)); // muda o cursor para maozinha qnd o usuario passa por cima
    }

    // aq abre a tela principal do jogo
    private void abrirTelaPrincipalDoJogo() {
        this.dispose(); // fecha a tela de login
        // swingutilities garante q nova tela seja criada na thread para nao dar
        // problema de desempenho
        SwingUtilities.invokeLater(() -> {
            new TelaPrincipal(jogo, new GameController(jogo)); // nova instancia na tela principal do jogo
        });
    }
}
