import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.text.Normalizer;

// A classe 'BancoPalavras' encapsula a lógica e os dados
public class BancoPalavras {
    //Este é o atributo que armazenará todas as palavras
    private List<String> palavras;

    //construtor da classe
    public BancoPalavras() {
        this.palavras = new ArrayList<>();
    }

    /**
     * Carrega as palavras de um arquivo de texto.
     * @param caminhoArquivo O caminho do arquivo que contém as palavras.
     * @throws IOException se houver um erro de leitura do arquivo.
     */

     //metodo responsavel por ler um arquivo de texto e  popular lista de palavras
    public void carregarPalavras(String caminhoArquivo) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                //lê o arquivo linha por linha
                // Remove acentos e caracteres especiais, depois converte para maiúsculas
                String palavraNormalizada = Normalizer.normalize(linha, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
                this.palavras.add(palavraNormalizada.trim().toUpperCase());
            }
        }
        if (this.palavras.isEmpty()) {
            throw new IOException("O arquivo de palavras está vazio.");
        }
    }

    /**
     * Seleciona uma palavra aleatória da lista.
     * @return Uma palavra aleatória de 5 letras.
     */

     //Este método permite que outras partes do código obtenham uma palavra para o jogo
    public String getPalavraAleatoria() {
        //Ela evita um erro se o método for chamado antes que as palavras tenham sido carregadas
        if (this.palavras.isEmpty()) {
            throw new IllegalStateException("O banco de palavras não foi carregado ou está vazio.");
        }
        Random random = new Random();
        int indice = random.nextInt(this.palavras.size());
        // Retorna a palavra na posição sorteada.
        return this.palavras.get(indice);
    }
}