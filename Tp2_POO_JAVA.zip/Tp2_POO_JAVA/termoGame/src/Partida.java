import java.text.Normalizer;

// Esta classe encapsula o estado e a lógica de uma única partida do jogo.
// Ela lida com a palavra a ser adivinhada, o número de tentativas e a
// verificação dos palpites do jogador.
public class Partida {

    private String palavraSecreta;
    private int tentativasRestantes;
    private static final int MAX_TENTATIVAS = 6;

    public Partida(String palavraSecreta) {
        String palavraNormalizada = Normalizer.normalize(palavraSecreta, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
        this.palavraSecreta = palavraNormalizada.toUpperCase();
        // Uma constante para o número máximo de tentativas
        this.tentativasRestantes = MAX_TENTATIVAS;
    }

    // Métodos `getter` para acessar os atributos privados da classe.
    public String getPalavraSecreta() {
        return palavraSecreta;
    }

    public int getTentativasRestantes() {
        return tentativasRestantes;
    }

    /**
     * Verifica uma tentativa do jogador contra a palavra secreta.
     * Retorna um array de EstadoLetra indicando a cor de cada letra.
     * @param tentativa a palavra de 5 letras do jogador.
     * @return um array de EstadoLetra com o resultado.
     */
    public EstadoLetra[] verificarTentativa(String tentativa) {
        // Normaliza e padroniza a tentativa do jogador
        String tentativaNormalizada = Normalizer.normalize(tentativa, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
        tentativaNormalizada = tentativaNormalizada.toUpperCase();
        
        EstadoLetra[] resultado = new EstadoLetra[5];

        char[] palavraSecretaArrayTemp = this.palavraSecreta.toCharArray();
        char[] tentativaArrayTemp = tentativaNormalizada.toCharArray();

        // 1. Primeiro, verificar as letras corretas (CORRETO - cor verde)
        for (int i = 0; i < 5; i++) {
            if (tentativaArrayTemp[i] == palavraSecretaArrayTemp[i]) {
                resultado[i] = EstadoLetra.CORRETO;
                palavraSecretaArrayTemp[i] = '_'; 
                tentativaArrayTemp[i] = '_';
            }
        }

        // 2. Depois, verificar as letras na posição errada (POSICAO_ERRADA - cor amarela)
        for (int i = 0; i < 5; i++) {
            if (tentativaArrayTemp[i] != '_') {
                boolean encontrou = false;
                for (int j = 0; j < 5; j++) {
                    if (tentativaArrayTemp[i] == palavraSecretaArrayTemp[j]) {
                        resultado[i] = EstadoLetra.POSICAO_ERRADA;
                        palavraSecretaArrayTemp[j] = '_';
                        encontrou = true;
                        break;
                    }
                }
                // Se a letra não foi encontrada, ela não existe na palavra.
                if (!encontrou) {
                    resultado[i] = EstadoLetra.NAO_EXISTE;
                }
            }
        }
         // Loop final para garantir que todas as posições tenham um valor.
        for (int i = 0; i < 5; i++) {
             if (resultado[i] == null) {
                resultado[i] = EstadoLetra.NAO_EXISTE;
            }
        }

        // Decrementa o contador de tentativas.
        tentativasRestantes--;
        return resultado;
    }

    //Verifica se o jogador acertou a palavra secreta.
    public boolean isVencedor(String tentativa) {
        String tentativaNormalizada = Normalizer.normalize(tentativa, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
        return tentativaNormalizada.equalsIgnoreCase(this.palavraSecreta);
    }

    //Normaliza a tentativa antes de comparar para evitar problemas com acentos.
    public boolean isFimDeJogo() {
        return tentativasRestantes <= 0;
    }
}