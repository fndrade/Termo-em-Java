import java.util.ArrayList;
import java.util.List;

// A classe `Jogo` é o ponto central do sistema.
//Ela gerencia as interações entre as outras classes 
//(BancoPalavras, Partida, Usuario, GerenciadorUsuario)

public class Jogo {

    //Atributos privados que representam as dependências da classe `Jogo`
    private BancoPalavras bancoDePalavras;
    private Partida partidaAtual;
    private Usuario usuarioAtual;
    private GerenciadorUsuario gerenciadorDeUsuarios;
    private List<String> palavrasUtilizadas;
    //Construtor da classe `Jogo`.
    public Jogo(String caminhoArquivoPalavras) throws Exception {
        // Inicializa o gerenciador de palavras e carrega o arquivo.
        this.bancoDePalavras = new BancoPalavras();
        this.bancoDePalavras.carregarPalavras(caminhoArquivoPalavras);

        // Inicializa o gerenciador de usuários.
        this.gerenciadorDeUsuarios = new GerenciadorUsuario();
        this.gerenciadorDeUsuarios.carregarUsuarios();
        // Inicializa a lista para evitar que a mesma palavra seja sorteada em uma mesma sessão de jogo.
        this.palavrasUtilizadas = new ArrayList<>();
    }
    //Métodos para gerenciar usuários, delegando as tarefas para o `GerenciadorUsuario`.
    public Usuario login(String username, String password) {
        this.usuarioAtual = gerenciadorDeUsuarios.autenticarUsuario(username, password);
        return this.usuarioAtual;
    }

    public boolean cadastrarUsuario(String username, String password) {
        return gerenciadorDeUsuarios.cadastrarUsuario(username, password);
    }
    // Método `getter` para obter o usuário logado no momento.
    public Usuario getUsuarioAtual() {
        return this.usuarioAtual;
    }
    // Inicia uma nova partida.
    //Seleciona uma palavra aleatória do banco de palavras, garantindo que
    //ela não tenha sido utilizada na sessão atual, e cria um novo objeto `Partida`.
    public void iniciarNovaPartida() {
        String palavraSecreta;
        do {
            palavraSecreta = bancoDePalavras.getPalavraAleatoria();
        } while (palavrasUtilizadas.contains(palavraSecreta));
        
         // Cria uma nova instância de `Partida`, passando a palavra secreta.
        this.partidaAtual = new Partida(palavraSecreta);
        this.palavrasUtilizadas.add(palavraSecreta);
    }
    // Método `getter` para obter a partida em andamento.
    public Partida getPartidaAtual() {
        return this.partidaAtual;
    }
    //Finaliza a partida e atualiza as estatísticas do usuário.
    public void finalizarPartida(boolean vitoria) {
        if (usuarioAtual != null) {
            if (vitoria) {
                usuarioAtual.registrarVitoria();
            } else {
                usuarioAtual.registrarDerrota();
            }
            // Chama o gerenciador para salvar os dados após a atualização.
            gerenciadorDeUsuarios.salvarUsuarios();
        }
    }

    //Método auxiliar para salvar os dados do usuário, útil para ser chamado ao fechar aplicativo
    public void salvarDados() {
        gerenciadorDeUsuarios.salvarUsuarios();
    }
}