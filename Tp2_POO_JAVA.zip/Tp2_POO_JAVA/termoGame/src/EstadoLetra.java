public enum EstadoLetra {//é uma enumeração que pode assumir apenas um dos três valores listados: 
    CORRETO,
    POSICAO_ERRADA,
    NAO_EXISTE
}
//A principal função desta enumeração é fornecer uma maneira clara, 
//segura e limitada de representar o resultado da avaliação de uma letra.