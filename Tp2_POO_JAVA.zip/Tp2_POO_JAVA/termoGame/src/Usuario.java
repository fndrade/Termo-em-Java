import java.io.Serializable;
//ela implementa a interface serializable
//para que possamos salvar e carregar os dados de um jogador
//isso é crucial para persistir os dados de um jogador entre diferentes sessões do jogo

public class Usuario implements Serializable {//classe usuario
//ela encapsula todos dados de um jogador(nome,senha,estatisticas de jogo)

//Ele garante que a versão da classe seja compatível quando o
//objeto é salvo e depois carregado.

    private static final long serialVersionUID = 1L;

    //Atributos da classe
    private String username;
    private String password;
    private int partidasJogadas;
    private int partidasGanhas;
    private int partidasPerdidas;
    private int sequenciaVitorias;
    private int melhorSequencia;

    //Construtor da classe
    public Usuario(String username, String password) {
        this.username = username;
        this.password = password;
        this.partidasJogadas = 0;
        this.partidasGanhas = 0;
        this.partidasPerdidas = 0;
        this.sequenciaVitorias = 0;
        this.melhorSequencia = 0;
    }

    //Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getPartidasJogadas() {
        return partidasJogadas;
    }

    public int getPartidasGanhas() {
        return partidasGanhas;
    }

    public int getPartidasPerdidas() {
        return partidasPerdidas;
    }

    public int getSequenciaVitorias() {
        return sequenciaVitorias;
    }

    public int getMelhorSequencia() {
        return melhorSequencia;
    }

    //Metodo chamado quando jogador vence a partida
    //Ele incrementa as estatísticas de vitória e de partidas jogadas.
    //Também atualiza a sequência de vitórias e a melhor sequência
    public void registrarVitoria() {
        this.partidasJogadas++;
        this.partidasGanhas++;
        this.sequenciaVitorias++;
        if (this.sequenciaVitorias > this.melhorSequencia) {
            this.melhorSequencia = this.sequenciaVitorias;
        }
    }
    //Este método é chamado quando o jogador perde uma partida.
    // Ele incrementa as estatísticas de derrota e de partidas jogadas.
    // A sequência de vitórias é reiniciada para zero, pois a sequência foi interrompida
    public void registrarDerrota() {
        this.partidasJogadas++;
        this.partidasPerdidas++;
        this.sequenciaVitorias = 0;
    }
}