import java.io.File;
import javax.swing.SwingUtilities;

// A classe `Principal` é a classe de entrada da aplicação.
public class Principal {

    public static void main(String[] args) {
        //1. Verificação de Argumentos
        // Esta parte do código verifica se o usuário forneceu o caminho do arquivo
        // de palavras como argumento de linha de comando.
        if (args.length < 1) {
            System.err.println("Erro: O caminho do arquivo de palavras não foi fornecido.");
            System.err.println("Uso: java -jar seu_jogo.jar <caminho_para_palavras.txt>");
            return;
        }

        String caminhoArquivoPalavras = args[0];

        // 2. Bloco `try-catch` para tratamento de erros
        // O código de inicialização está dentro de um bloco `try` para capturar
        // e tratar quaisquer exceções que possam ocorrer durante o processo.
        try {
            File palavrasFile = new File(caminhoArquivoPalavras);
            if (!palavrasFile.exists()) {
                System.err.println("Erro: O arquivo de palavras não foi encontrado no caminho: " + caminhoArquivoPalavras);
                return;
            }
            
            // 3. Inicialização dos componentes
            // Cria instâncias das classes principais do jogo:
            //`Jogo`: A classe central que gerencia toda a lógica do jogo.
            final Jogo jogo = new Jogo(caminhoArquivoPalavras);
            // `AuthController`: A classe que provavelmente gerencia o fluxo de login e cadastro.
            final AuthController authController = new AuthController(jogo);

            // 4. Threading para a Interface Gráfica (GUI)
            // `SwingUtilities.invokeLater` garante que a criação da interface
            // gráfica (`TelaLogin`) ocorra na `Event Dispatch Thread` (EDT).
            SwingUtilities.invokeLater(() -> {
                // Cria a janela de login, passando os controladores necessários.
                new TelaLogin(authController, jogo);
            });

        } catch (Exception e) {
            // Em caso de erro, a mensagem é exibida para o usuário
            // e o rastreamento de pilha é impresso para depuração.
            System.err.println("Ocorreu um erro fatal ao iniciar o jogo: " + e.getMessage());
            e.printStackTrace();
        }
    }
}