import java.io.*;
import java.util.HashMap;
import java.util.Map;

// A classe `GerenciadorUsuario` é responsável por gerenciar todas as operações
// relacionadas a usuários: carregar, salvar, cadastrar e autenticar.
public class GerenciadorUsuario {

    // Define o caminho do arquivo onde os dados dos usuários serão salvos.
    private static final String ARQUIVO_USUARIOS = "resources/usuarios.dat";
    // A estrutura de dados para armazenar os usuários. 
    private Map<String, Usuario> usuarios;

    //Construtor da classe `GerenciadorUsuario`.
    public GerenciadorUsuario() {
        this.usuarios = new HashMap<>();
        carregarUsuarios();
    }
    //Carrega os usuários do arquivo binário.
    //@SuppressWarnings("unchecked") é usado para suprimir o aviso do compilador sobre a conversão de tipo 
    @SuppressWarnings("unchecked")
    public void carregarUsuarios() {
        //try-with-resources garante que o stream de entrada de objetos
        // seja fechado automaticamente.
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARQUIVO_USUARIOS))) {
            this.usuarios = (Map<String, Usuario>) ois.readObject();
            System.out.println("Usuários carregados com sucesso.");
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo de usuários não encontrado. Será criado um novo.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //Salva todos os usuários no arquivo binário.
    //Utiliza `ObjectOutputStream` para serializar o mapa de usuários.
    public void salvarUsuarios() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARQUIVO_USUARIOS))) {
            oos.writeObject(this.usuarios);
            System.out.println("Usuários salvos com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //Cadastra um novo usuário no sistema.
    public boolean cadastrarUsuario(String username, String password) {
        // Verifica se o nome de usuário já está em uso.
        if (usuarios.containsKey(username)) {
            System.out.println("Usuário " + username + " já existe.");
            return false;
        }
        // Cria um novo objeto `Usuario` e o adiciona ao mapa.
        Usuario novoUsuario = new Usuario(username, password);
        usuarios.put(username, novoUsuario);
        // Salva os dados atualizados no arquivo.
        salvarUsuarios();
        return true;
    }
    //Autentica um usuário com base no nome de usuário e senha.
    public Usuario autenticarUsuario(String username, String password) {
        Usuario usuario = usuarios.get(username);
        if (usuario != null && usuario.getPassword().equals(password)) {
            return usuario;
        }
        return null;
    }
    //Retorna um objeto `Usuario` com base no nome de usuário.
    public Usuario getUsuario(String username) {
        return usuarios.get(username);
    }
}