// Esta é a classe AuthController, o nosso controlador de autenticação.
public class AuthController {

    /*
     * A classe tem uma referência para a classe 'Jogo'.
     * É com essa referência que ela consegue interagir com a lógica do jogo para
     * fazer o login e o cadastro
     */
    private Jogo jogo;

    // O construtor recebe a instância da classe 'Jogo' para poder usar os métodos
    // dela.
    public AuthController(Jogo jogo) {
        this.jogo = jogo;
    }

    // Métodos de Lógica

    // Este método lida com a ação de login.
    // Ele recebe o nome de usuário e a senha da tela de login.
    public Usuario handleLogin(String username, String password) {
        /*
         * O controlador não faz a lógica de login ele mesmo.
         * Ele apenas "passa a bola" para a classe 'Jogo' e retorna o resultado.
         * Isso mantém a responsabilidade separada.
         */
        return jogo.login(username, password);
    }

    // Este método lida com a ação de cadastro.
    // Ele recebe as informações da tela de cadastro.
    public boolean handleCadastro(String username, String password) {
        /*
         * Assim como no login, o controlador repassa a solicitação
         * para a classe 'Jogo', que é quem realmente sabe como criar um novo usuário.
         * O retorno 'boolean' informa se o cadastro deu certo ou não.
         */
        return jogo.cadastrarUsuario(username, password);
    }
}