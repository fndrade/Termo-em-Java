public class GameController {

    // é através dessa classe que o controlador acessa e manipula o estado do jogo.
    private Jogo jogo;

    // Construtor
    // Quando o controlador é criado, ele recebe a instância do jogo que ele vai
    // gerenciar.
    public GameController(Jogo jogo) {
        this.jogo = jogo;
    }

    // Métodos de Lógica

    // Método chamado quando o jogador quer começar uma nova partida, o controlador
    // apenas repassa o comando para a classe 'Jogo'.
    public void iniciarNovaPartida() {
        jogo.iniciarNovaPartida();
    }

    // Este é um dos métodos principais. Ele recebe a tentativa do jogador.
    public EstadoLetra[] processarTentativa(String tentativa) {
        // Primeiro, pega a partida atual na classe 'Jogo'.
        Partida partida = jogo.getPartidaAtual();

        // Uma verificação de segurança para garantir que a partida exista.
        if (partida == null) {
            System.out.println("Nenhuma partida em andamento.");
            return null;
        }

        // Delega a tarefa de verificar a tentativa para a classe 'Partida' e armazena o
        // resultado (se a letra está correta, errada, etc.).
        EstadoLetra[] resultado = partida.verificarTentativa(tentativa);

        // Verifica se o jogador venceu com essa tentativa.
        if (partida.isVencedor(tentativa)) {
            // Se sim, chama o método para finalizar a partida, passando 'true' para
            // vitória.
            jogo.finalizarPartida(true);
            // Ou, se o jogo chegou ao fim por falta de tentativas.
        } else if (partida.isFimDeJogo()) {
            // Chama o método para finalizar a partida, passando 'false' para derrota.
            jogo.finalizarPartida(false);
        }

        // Retorna o array com os estados de cada letra para que a interface saiba como
        // colorir as caixinhas.
        return resultado;
    }

    // Métodos simples para "pegar" informações do jogo e da partida, o controlador
    // serve como um "ponte" para a tela acessar esses dados.
    public Usuario getUsuarioAtual() {
        return jogo.getUsuarioAtual();
    }

    public Partida getPartidaAtual() {
        return jogo.getPartidaAtual();
    }

    // Método chamado para sair do jogo.
    public void sairDoJogo() {
        // O controlador é responsável por garantir que os dados sejam salvos antes de o
        // programa ser encerrado.
        jogo.salvarDados();
        // encerra a aplicação.
        System.exit(0);
    }
}